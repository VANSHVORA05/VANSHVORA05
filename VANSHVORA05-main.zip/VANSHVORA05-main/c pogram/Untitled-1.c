#include<stdio.h>

int main()
{
    int x,y,t;

x=10,y=5;

t=x;
x=y;
y=t;
printf("x is %d",x=y);
printf("y is %d",y=x);

}