#include<stdio.h>
int main()
{
    int x,y,b;
    x=10,y=5;


    // printf("enter your x:-");
    // scanf("%d",&x);
    

    // printf("enter your y:-");
    // scanf("%d",&y);

// b=(x+y)*(x+y);

    printf("(x+y)^2 = %d",(x+y)*(x+y));

    // printf("%d",b);
}