#include<stdio.h>

int main()
{
    printf("-----------");
    printf("\n|\t|");
    printf("\nR\t| ");
    return 0;
}