#include<stdio.h>

int main()
{
    int a=12,b=6,sub;
    sub=a-b;
   
    printf("%d - %d = %d",a,b,sub);

  
}