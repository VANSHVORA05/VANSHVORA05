#include<stdio.h>

int main()
{
    int a,b;
    a=5,b=6;

    a=b;
    b=a;

    printf("a=%d",a=b);

}