#include<stdio.h>

int main()
{
    int a=5,b=5;
    printf("\n------------");
    printf("\n|          |");
    printf("\n|%d x %d = %d|",a,b,a*b);
    printf("\n|          |");
    printf("\n------------");
}