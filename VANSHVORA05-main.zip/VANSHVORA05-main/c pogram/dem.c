#include<stdio.h>

void main()
{
    int rollno=15;
    float avg=50.55;
    char grade= 'C';
    char name[]="kush patel";

    printf("\n rollno is=%d",rollno);
    printf("\n avg is=%.2f",avg);
    printf("\n grade=%c",grade);
    printf("\n name=%s",name);

  
}