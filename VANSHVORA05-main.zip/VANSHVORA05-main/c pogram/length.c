#include<stdio.h>

int main()
{
    int l;
    printf("Enter your length:-");
    scanf("%d",&l);

    printf("areaof rectangle :-%d",l*l,l);
}
