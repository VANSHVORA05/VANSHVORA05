#include<stdio.h>
#include<conio.h>
void  main()
{
    int a,b;

    printf("Enter your value A:");
    scanf("%d",&a);

    printf("Enter your value B:");
    scanf("%d",&b);

    a>=b
    ? printf("A is max")
    : printf("B is max");

    getch()
}