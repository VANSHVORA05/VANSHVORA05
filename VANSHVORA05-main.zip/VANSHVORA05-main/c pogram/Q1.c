#include<stdio.h>

int main()
{
    printf("name :- kush patel");
    printf("\nage  :- 20");
    printf("\nclg  :- r&w ");
    return 0;
}