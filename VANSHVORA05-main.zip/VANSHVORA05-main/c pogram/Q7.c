c
{
    int num =1;
    if(num ==2
    )
    {
        printf("hii");
    }
else
{
    printf("hello");
}
   
}
