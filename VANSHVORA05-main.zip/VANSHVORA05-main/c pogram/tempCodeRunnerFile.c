#include<stdio.h>

int main()
{
    //int n ;
    //printf("enter value of n= ")
    //scanf("%d",&n);

    for(i=1;i<=10;i++)
    printf("\n %d ",i);
    }